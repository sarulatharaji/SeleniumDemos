package com.cg.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class ValidationLab3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/sarulatha/M4/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Loading page using get() method
		driver.get("http://demo.opencart.com/");
		//Verifying page title
		System.out.println("Verifying Home page Title"+" "+driver.getTitle().equals("Your Store"));
		//Choosing Myaccount from dropdown
		driver.findElement(By.linkText("My Account")).click();
		//Directing to Registration page
		driver.findElement(By.partialLinkText("Reg")).click();
		//Verifying Register account page
		System.out.println("Verifying Register page title"+" "+driver.getTitle().equals("Register Account"));
		//Filling Registration Page
		driver.findElement(By.id("input-firstname")).sendKeys("SarulathaRajendrandKishoreBakkiyamSaras");
		driver.findElement(By.xpath("//input[@class='btn btn-primary']")).click();
		String fnamerror=driver.findElement(By.name("firstName")).getText();
		Assert.assertEquals(fnamerror, "First Name must be between 1 and 32 characters!");
	}

}
