package org.openqa.selenium.demos;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DanceTest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/sarulatha/M4/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("file:///D:/sarulatha/M4/Dance_Class_Enquiry.html");
		//firstname by id
		driver.findElement(By.id("fname")).sendKeys("saru");
//		lastname by id
		driver.findElement(By.id("lname")).sendKeys("latha");
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("sara@gmail.com");
		driver.findElement(By.cssSelector("input[id='mobile']")).sendKeys("8745698231");
		Select tuition=new Select(driver.findElement(By.name("D6")));
		tuition.selectByValue("chacha");
		Select preference=new Select(driver.findElement(By.name("D5")));
		preference.selectByIndex(2);
		Select learning=new Select(driver.findElement(By.name("D4")));
		learning.selectByVisibleText("Class rooom training");
		driver.findElement(By.id("enqdetails")).sendKeys("Regarding class timings");
		System.out.println(driver.getPageSource().contains("Enquiry Details Form"));
		driver.findElement(By.id("Submit1")).click();
		Alert alert=driver.switchTo().alert();
		System.out.println(alert.getText());
		alert.accept();
		System.out.println(driver.getPageSource().contains("Our Counselor will contact you soon."));
		Thread.sleep(2000);
		driver.close();
	}
}
